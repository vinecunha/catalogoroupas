## Produção de Texto Individual

## Para que está sendo desenvolvido?

Este repositório foi desenvolvido para entrega da PTI do curso de graduação tecnológica do EAD SENAC-SP. Esta entrega é requisito para obtenção da aprovação na matéria de DESENVOLVIMENTO DE API REST do curso de Sistemas para Internet.

POST: ´http:localhost:5000/roupa´
GET: ´http:localhost:5000/roupa?nome="Camiseta"´
PUT: ´http:localhost:5000/roupa/1´
DELETE: ´http:localhost:5000/roupa/1´

* Autor: Vinicius Cunha Martins